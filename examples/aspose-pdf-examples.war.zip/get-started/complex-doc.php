<?php

require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

use com\aspose\pdf\Document;
use com\aspose\pdf\TextFragment;
use com\aspose\pdf\License;
use com\aspose\pdf\Rectangle;
use com\aspose\pdf\HorizontalAlignment;
use com\aspose\pdf\Position;
use com\aspose\pdf\FontRepository;
use com\aspose\pdf\Table;
use com\aspose\pdf\BorderInfo;
use com\aspose\pdf\BorderSide;
use com\aspose\pdf\Color;

$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";
$licenceObject = new License();
$licenceObject->setLicense($license);

$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'complex-doc.pdf';

header('Content-Type: application/json; charset=utf-8');

try {
    $document = new Document();
    $horizontalAlignment = new HorizontalAlignment();
    
    //Add page
    $page = $document->getPages()->add();
        
    // Add image
    $imageFileName = $dataDir . DIRECTORY_SEPARATOR . 'logo.png';
    $page->AddImage($imageFileName, new Rectangle(20, 730, 120, 830));

    // Add Header
    $fontRepository = new FontRepository();
    $fontArial = $fontRepository->findFont("Arial");

    $header = new TextFragment("New ferry routes in Fall 2020");
    $header->getTextState()->setFont($fontArial);
    $header->getTextState()->setFontSize(24);
    
    $header->setHorizontalAlignment($horizontalAlignment->Center);
    $header->setPosition(new Position(130, 720));
    $page->getParagraphs()->add($header);

    // Add description
    $descriptionText = "Visitors must buy tickets online and tickets are limited to 5,000 per day. Ferry service is operating at half capacity and on a reduced schedule. Expect lineups.";
    $description = new TextFragment($descriptionText);
    $description->getTextState()->setFont($fontRepository->findFont("Times New Roman"));
    $description->getTextState()->setFontSize(14);
    $header->setHorizontalAlignment($horizontalAlignment->Center);
    $page->getParagraphs()->add($description);

    // Add table
    $table = new Table();
    $table->setColumnWidths("200");

    $colors = new Color();
    $darkSlateGrayColor = $colors->getDarkSlateGray();
    $blackColor = $colors->getBlack();
    $grayColor = $colors->getGray();
    $whiteSmokeColor = $colors->getWhiteSmoke();
    $borderSide = new BorderSide();

    $table->setBorder(new BorderInfo($borderSide->Box, 1.0, $darkSlateGrayColor));
    $table->setDefaultCellBorder(new BorderInfo($borderSide->Box, 0.5, $blackColor));
    $table->getMargin()->setBottom(10);
    $table->getDefaultCellTextState()->setFont($fontRepository->findFont("Helvetica"));

    $headerRow = $table->getRows()->add();

    $headerRowCell = $headerRow->getCells()->add("Departs City");
    $headerRowCell->setBackgroundColor($grayColor);
    $headerRowCell->getDefaultCellTextState()->setForegroundColor($whiteSmokeColor);

    $headerRowCell = $headerRow->getCells()->add("Departs Island");
    $headerRowCell->setBackgroundColor($grayColor);
    $headerRowCell->getDefaultCellTextState()->setForegroundColor($whiteSmokeColor);

    $timenow = new DateTime('06:00');

    for ($i = 0; $i < 10; $i++) {
        $dataRow = $table->getRows()->add();
        $cell = $dataRow->getCells()->add($timenow->format('H:i'));
        $timenow->add(new DateInterval('PT30M'));
        $dataRow->getCells()->add($timenow->format('H:i'));
    }

    $page->getParagraphs()->add($table);

    $document->save($outputFile);
    $responseData = "Document has been created successfully. Filesize: " . filesize($outputFile);

} catch (Exception $ex) {
    header($_SERVER['SERVER_PROTOCOL'] . ' 500 Internal Server Error', true, 500);
    $responseData = $ex;
}

echo '{"message":"' . $responseData . '"}' . PHP_EOL;

