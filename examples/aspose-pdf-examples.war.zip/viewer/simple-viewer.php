<?php

require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

use com\aspose\pdf\Document;
use com\aspose\pdf\License;
use com\aspose\pdf\devices_PngDevice;
use com\aspose\pdf\devices_Resolution;

$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";
$licenceObject = new License();
$licenceObject->setLicense($license);

$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . 'sample.pdf';
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'output_page_';

header('Content-Type: application/json; charset=utf-8');

try {
    $document = new Document();    
    // Load the source PDF document
    $document = new Document($inputFile);
    // Iterate through each page in the PDF
    for ($pageCount = 1; $pageCount <= $document->getPages()->size(); $pageCount++) {
        
        // Get the page from the document
        $page = $document->getPages()->get_Item($pageCount);

        // Remove annotations from the page
        $page->getAnnotations()->clear();

        // Create a PNG device with a resolution of 96 dpi
        $pngDevice = new devices_PngDevice(new devices_Resolution(96));

        // Convert the page to PNG and save it
        $pngDevice->process($page, $outputFile . $pageCount . ".png");
    }
    $document->close();

    $responseData = "Document has been created successfully.";
} catch (Exception $ex) {
    $responseData = $ex->getMessage();
}

echo '{"message":"' . $responseData . '"}' . PHP_EOL;
