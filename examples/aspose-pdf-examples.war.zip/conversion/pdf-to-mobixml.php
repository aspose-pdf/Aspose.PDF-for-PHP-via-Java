<?php

/**
 * This code demonstrates how to convert a PDF document to MOBI format using the  <a class="is-link" href="/AsposePdfExamples/">Aspose.PDF for PHP via Java</a> library.
 */

// Include the required libraries
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the  <a class="is-link" href="/AsposePdfExamples/">Aspose.PDF for PHP via Java</a> library
use com\aspose\pdf\Document;
use com\aspose\pdf\MobiXmlSaveOptions;
use com\aspose\pdf\License;

// Set the path to the Aspose.PDF.PHPviaJava license file
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new License object and set the license file
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the input and output files
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.pdf";
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-pdf-to-mobi.mobi';

// Set the response header
header('Content-Type: application/json; charset=utf-8');

try {
    // Load the PDF document
    $document = new Document($inputFile);

    // Create an instance of the MobiXmlSaveOptions class
    $saveOption = new MobiXmlSaveOptions();

    // Save the document as MOBI format
    $document->save($outputFile, $saveOption);
} catch (Exception $ex) {
    // Handle any exceptions that occur during the conversion process
    echo json_encode($ex);
}

// Generate the response message
$responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile);

// Return the response message as JSON
echo '{"message":"' . $responseData . '"}' . PHP_EOL;