<?php

/**
 * PDF to Text Converter
 *
 * This script converts a PDF document to plain text using the Aspose.PDF library.
 * It requires the Aspose.PDF for Java library and a valid license file.
 * The converted text is saved to a file and the file size is returned as a response.
 */

// Include the required libraries
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the Aspose.PDF library
use com\aspose\pdf\Document;
use com\aspose\pdf\TextAbsorber;
use com\aspose\pdf\License;

// Set the path to the license file
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new License object and set the license file
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the input PDF file
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.pdf";

// Set the path to the output text file
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-pdf-to-text.txt';

// Set the response header
header('Content-Type: application/json; charset=utf-8');

try {
    // Load the PDF document
    $document = new Document($inputFile);

    // Create a TextAbsorber object to extract text from the document
    $textAbsorber = new TextAbsorber();

    // Extract the text from the document
    $textAbsorber->visit($document);
    $content = $textAbsorber->getText();

    // Save the extracted text to the output file
    file_put_contents($outputFile, $content);

    // Get the file size of the output file
    $fileSize = filesize($outputFile);

    // Create the response message
    $responseData = "Document has been converted successfully. Filesize: " . $fileSize;

    // Return the response message as JSON
    echo '{"message":"' . $responseData . '"}' . PHP_EOL;

} catch (Exception $ex) {
    // If an exception occurs, return the error message as JSON
    echo json_encode($ex);
}


// try {
//     // Load the PDF document
//     $document = new Document($inputFile);

//     // Create a TextAbsorber object to extract text from the document
//     $textAbsorber = new TextAbsorber();

//     $array = array(1, 3, 4);

//     foreach ($array as $page) {
//         $textAbsorber->visit($document->getPages()->get_Item($page));
//         $content = $textAbsorber->getText();
        
//         $outputFile = $dataDir . DIRECTORY_SEPARATOR . 'result-pdf-to-text'. $page . '.txt';
//         // Save the extracted text to the output file
//         file_put_contents($outputFile, $content);
//     }

//     // Create the response message
//     $responseData = "Document has been converted successfully. Filesize: " . $fileSize;

//     // Return the response message as JSON
//     echo '{"message":"' . $responseData . '"}' . PHP_EOL;

// } catch (Exception $ex) {
//     // If an exception occurs, return the error message as JSON
//     echo json_encode($ex);
// }