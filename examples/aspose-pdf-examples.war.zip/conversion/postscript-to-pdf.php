<?php

/**
 * This code demonstrates the usage of Aspose.PDF for Java library to convert a PostScript (PS) file to PDF format.
 * It utilizes the Java.inc bridge to interact with the Java library from PHP.
 */

// Include the required Java.inc and Aspose.PDF.php files.
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the Aspose.PDF namespace.
use com\aspose\pdf\Document;
use com\aspose\pdf\PsLoadOptions;
use com\aspose\pdf\License;

// Set the path to the Aspose.PDF license file.
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new License object and set the license file.
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the input and output files.
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample1.ps";
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-ps-to-pdf.pdf';

// Set the response header to indicate JSON content.
header('Content-Type: application/json; charset=utf-8');

try {
    // Create a new PsLoadOptions object.
    $loadOption = new PsLoadOptions();

    // Create a new Document object and load the input PS file.
    $document = new Document($inputFile, $loadOption);

    // Save the document as a PDF file    
    $document->save($outputFile);
    
    // Prepare the response data.
    $responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile);
   
} catch (Exception $ex) {
    // Echo the exception as a JSON string.
    $responseData = $ex;
}

 // Echo the response data as a JSON string.
 echo '{"message":"' . $responseData . '"}' . PHP_EOL;