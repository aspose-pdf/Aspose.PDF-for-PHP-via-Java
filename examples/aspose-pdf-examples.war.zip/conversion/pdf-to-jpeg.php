<?php

/**
 * This script converts a PDF document to JPEG images using the  <a class="is-link" href="/AsposePdfExamples/">Aspose.PDF for PHP via Java</a> library.
 * It requires the  <a class="is-link" href="/AsposePdfExamples/">Aspose.PDF for PHP via Java</a> library and a valid license file.
 */

// Include the required libraries
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the  <a class="is-link" href="/AsposePdfExamples/">Aspose.PDF for PHP via Java</a> library
use com\aspose\pdf\Document;
use com\aspose\pdf\devices_Resolution;
use com\aspose\pdf\devices_JpegDevice;
use com\aspose\pdf\License;

// Set the path to the license file
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a License object and set the license file
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the input PDF file
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.pdf";

// Set the path and template for the output JPEG files
$imageFileNameTemplate = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-pdf-to-jpeg-';

// Set the response content type to JSON
header('Content-Type: application/json; charset=utf-8');

// Initialize the response data variable
$responseData = "";

try {
    // Open the target document
    $document = new Document($inputFile);
    $pages = $document->getPages();
    $count = $pages->size();

    // Create a Resolution object with a resolution of 300 dpi
    $resolution = new devices_Resolution(300);

    // Create a JpegDevice object with the specified resolution
    $imageDevice = new devices_JpegDevice($resolution);

    // Loop through each page of the document
    for ($pageCount = 1; $pageCount <= $document->getPages()->size(); $pageCount++) {
        // Convert a particular page and save the image to a file
        $imageFileName = $imageFileNameTemplate . $pageCount . '.jpg';
        $page = $document->getPages()->get_Item($pageCount);
        $imageDevice->process($page, $imageFileName);

        // Append a success message to the response data
        $responseData = "Document has been converted successfully. Filesize: " . filesize($imageFileName);
    }
} catch (Exception $ex) {
    // If an exception occurs, encode and output the exception as JSON
    $responseData = json_encode($ex);
}

// Encode and output the response data as JSON
echo '{"message":"' . $responseData . '"}' . PHP_EOL;