<?php

/**
 * Convert XPS to PDF
 *
 * This script converts an XPS file to a PDF file using the Aspose.PDF for Java library.
 * It requires the Aspose.PDF for Java library and a valid license file to run.
 * The converted PDF file is saved to the specified output location.
 */
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

use com\aspose\pdf\Document;
use com\aspose\pdf\XpsLoadOptions;
use com\aspose\pdf\License;

// Set the path to the Aspose.PDF license file
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new instance of the License class and set the license file
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the input XPS file
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.oxps";

// Set the path to the output PDF file
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-xps-to-pdf.pdf';

// Set the response content type to JSON
header('Content-Type: application/json; charset=utf-8');

try {
    // Create a new instance of the XpsLoadOptions class
    $loadOption = new XpsLoadOptions();

    // Create a new instance of the Document class and load the XPS file
    $document = new Document($inputFile, $loadOption);

    // Save the document as a PDF file
    $document->save($outputFile);
} catch (Exception $ex) {
    // If an exception occurs, return the error message as JSON
    echo json_encode($ex);
}

// Generate the response data
$responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile);

// Return the response data as JSON
echo '{"message":"' . $responseData . '"}' . PHP_EOL;
?>