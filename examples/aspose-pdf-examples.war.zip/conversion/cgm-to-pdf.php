<?php

/**
 * This code demonstrates the conversion of a CGM (Computer Graphics Metafile) file to PDF using the Aspose.PDF library.
 * It utilizes the Java.inc library to interact with the Aspose.PDF library, which is a Java library.
 */

// Include the required libraries
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the Aspose.PDF library
use com\aspose\pdf\CgmLoadOptions;
use com\aspose\pdf\Document;
use com\aspose\pdf\License;

// Set the license file path
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a License object and set the license using the provided file path
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the directory path for input and output files
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";

// Set the input file path
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.cgm";

// Set the output file path
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-cgm-to-pdf.pdf';

// Set the response header
header('Content-Type: application/json; charset=utf-8');

try {
    // Create an instance of CgmLoadOptions to specify any specific options for loading the CGM file
    $options = new CgmLoadOptions();

    // Create a Document object and load the CGM file using the specified options
    $document = new Document($inputFile, $options);

    // Save the document as a PDF file
    $document->save($outputFile);
} catch (Exception $ex) {
    // If an exception occurs, encode the exception message as JSON and echo it
    echo json_encode($ex);
}

// Generate a response message with the file size of the converted PDF document
$responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile);

// Echo the response message as JSON
echo '{"message":"' . $responseData . '"}' . PHP_EOL;