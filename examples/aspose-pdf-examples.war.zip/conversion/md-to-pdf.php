<?php

/**
 * This script demonstrates how to convert a Markdown file to PDF using the Aspose.PDF for PHP library.
 * It requires the Aspose.PDF for Java library and a valid license file.
 */

// Include the required libraries
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the Aspose.PDF for PHP library
use com\aspose\pdf\Document;
use com\aspose\pdf\MdLoadOptions;
use com\aspose\pdf\License;

// Set the path to the Aspose.PDF for PHP license file
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new License object and set the license file
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the input Markdown file
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.md";

// Set the path to the output PDF file
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-md-to-pdf.pdf';

// Set the response header
header('Content-Type: application/json; charset=utf-8');

try {
    // Create a new instance of MdLoadOptions
    $loadOption = new MdLoadOptions();

    // Create a new instance of Document and load the input Markdown file
    $document = new Document($inputFile, $loadOption);

    // Save the document as a PDF file
    $document->save($outputFile);
} catch (Exception $ex) {
    // Handle any exceptions and return the error message as JSON
    echo json_encode($ex);
}

// Generate the response data
$responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile);

// Return the response data as JSON
echo '{"message":"' . $responseData . '"}' . PHP_EOL;
