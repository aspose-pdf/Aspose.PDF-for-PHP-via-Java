<?php

/**
 * Convert BMP to PDF
 *
 * This script converts a BMP image file to a PDF document using the Aspose.PDF for PHP library.
 * It utilizes the Java bridge to interact with the Java-based Aspose.PDF library.
 * The converted PDF document is saved to the specified output file.
 */
 
// Include the required files and classes from the Aspose.PDF library
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the Aspose.PDF library
use com\aspose\pdf\Document;
use com\aspose\pdf\Image;
use com\aspose\pdf\License;

// Set the path to the Aspose.PDF license file
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new License object and set the license file
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the input BMP file
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.bmp";

// Set the path to the output PDF file
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-bmp-to-pdf.pdf';

// Set the response header to indicate JSON content
header('Content-Type: application/json; charset=utf-8');

try {
    // Create a new Document object
    $document = new Document();

    // Add a new page to the document
    $page = $document->getPages()->add();

    // Set the margins of the page to 0
    $page->getPageInfo()->getMargin()->setBottom(0);
    $page->getPageInfo()->getMargin()->setTop(0);
    $page->getPageInfo()->getMargin()->setRight(0);
    $page->getPageInfo()->getMargin()->setLeft(0);
    
    // Create a new Image object and set the input BMP file
    $image = new Image();
    $image->setFile($inputFile);
    
    // Add the image to the page
    $page->getParagraphs()->add($image);

    // Save the document to the output PDF file
    $document->save($outputFile);
} catch (Exception $ex) {
    // If an exception occurs, encode the exception as JSON and output it
    echo json_encode($ex);
}

// Generate the response data
$responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile);

// Encode the response data as JSON and output it
echo '{"message":"' . $responseData . '"}' . PHP_EOL;