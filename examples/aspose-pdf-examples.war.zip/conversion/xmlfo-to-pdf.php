<?php

/**
 * This code demonstrates the usage of the Aspose.PDF for Java library to convert XML-FO (XSL-FO) files to PDF format.
 * It utilizes the Java.inc library to interact with the Java code from PHP.
 * The code requires a valid Aspose.PDF license file to be set in order to work properly.
 */

// Include the required libraries
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the Aspose.PDF for Java library
use com\aspose\pdf\Document;
use com\aspose\pdf\XslFoLoadOptions;
use com\aspose\pdf\License;

// Set the path to the Aspose.PDF license file
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new instance of the License class and set the license file
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the sample files
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFoFile = $dataDir . DIRECTORY_SEPARATOR . "sample.xslt";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.xml";
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-xmlfo-to-pdf.pdf';

// Set the response header
header('Content-Type: application/json; charset=utf-8');

try {
    // Create a new instance of the XslFoLoadOptions class and pass the input XSL-FO file path
    $loadOption = new XslFoLoadOptions($inputFoFile);

    // Create a new instance of the Document class and pass the input XML file and the XSL-FO load options
    $document = new Document($inputFile, $loadOption);

    // Save the converted PDF document to the output file path
    $document->save($outputFile);

    // Prepare the response data
    $responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile);

    // Echo the response data as a JSON string
    echo '{"message":"' . $responseData . '"}' . PHP_EOL;
} catch (Exception $ex) {
    // Echo the exception as a JSON string
    echo json_encode($ex);
}