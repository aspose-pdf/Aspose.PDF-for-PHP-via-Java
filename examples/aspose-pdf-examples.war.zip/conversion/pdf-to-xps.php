<?php

/**
 * This code demonstrates how to convert a PDF document to XPS format using the Aspose.PDF library.
 * It utilizes the Java.inc library to interact with the Java-based Aspose.PDF library.
 */

// Include the necessary libraries
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the required classes from the Aspose.PDF library
use com\aspose\pdf\Document;
use com\aspose\pdf\XpsSaveOptions;
use com\aspose\pdf\License;

// Set the path to the Aspose.PDF license file
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new License object and set the license using the provided file path
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the directory containing the input and output files
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";

// Set the path to the input PDF file
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.pdf";

// Set the path to the output XPS file
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-pdf-to-xps.xps';

// Set the response header to indicate that the response will be in JSON format
header('Content-Type: application/json; charset=utf-8');

try {
    // Create a new Document object and load the input PDF file
    $document = new Document($inputFile);

    // Create a new XpsSaveOptions object
    $saveOption = new XpsSaveOptions();

    // Save the document as XPS using the specified save options
    $document->save($outputFile, $saveOption);
} catch (Exception $ex) {
    // If an exception occurs, encode the exception message as JSON and echo it
    echo json_encode($ex);
}

// Generate the response data
$responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile);

// Echo the response data as JSON
echo '{"message":"' . $responseData . '"}' . PHP_EOL;
