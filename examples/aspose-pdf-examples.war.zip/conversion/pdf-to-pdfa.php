<?php

/**
 * This code demonstrates the usage of the Aspose.PDF for Java library to convert a PDF document to PDF/A-1a format.
 * It utilizes the Java.inc bridge to interact with the Java library from PHP.
 */

// Include the required Java.inc file and the Aspose.PDF library file.
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the Aspose.PDF library.
use com\aspose\pdf\Document;
use com\aspose\pdf\ConvertErrorAction;
use com\aspose\pdf\License;
use com\aspose\pdf\PdfFormat;

// Set the license file path.
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new License object and set the license using the provided file path.
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the directory path for the input and output files.
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";

// Set the input file path.
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.pdf";

// Set the log file path for conversion errors.
$logFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'log-pdf-to-pdfa.xml';

// Set the output file path for the converted PDF/A-1a document.
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-pdf-to-pdfa.pdf';

// Initialize the response variable.
$res = false;

// Set the response header to indicate JSON content type.
header('Content-Type: application/json; charset=utf-8');

try {
    // Create a new Document object and load the input PDF file.
    $document = new Document($inputFile);

    // Convert the document to PDF/A-1a format and specify the log file and error action.    
    $res = $pdf->convert($logFile, (new PdfFormat())->PDF_A_1A, (new ConvertErrorAction())->Delete);

    // Save the converted document to the output file.
    $document->save($outputFile);
} catch (Exception $ex) {
    $document->close();
    // If an exception occurs, encode the exception message as JSON and echo it.
    echo json_encode($ex);
}

// Check the conversion result and generate the response message accordingly.
if ($res === false) {
    $responseData = "Document has NOT been converted successfully. Filesize: " . filesize($outputFile);
} else {
    $responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile);
}

// Echo the response message as JSON.
echo '{"message":"' . $responseData . '"}' . PHP_EOL;
