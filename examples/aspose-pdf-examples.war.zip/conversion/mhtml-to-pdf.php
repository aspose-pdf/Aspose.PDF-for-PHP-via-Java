<?php

/**
 * This script demonstrates how to convert an MHTML file to PDF using the Aspose.PDF for PHP library.
 */

// Include the required files from the Aspose.PDF for PHP library.
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the Aspose.PDF namespace.
use com\aspose\pdf\Document;
use com\aspose\pdf\MhtLoadOptions;
use com\aspose\pdf\License;

// Set the path to the Aspose.PDF license file.
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new instance of the License class and set the license file.
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the input MHTML file.
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.mhtml";

// Set the path to the output PDF file.
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-mhtml-to-pdf.pdf';

// Set the response header to indicate that the response will be in JSON format.
header('Content-Type: application/json; charset=utf-8');

try {    
    // Create a new instance of the MhtLoadOptions class.
    $loadOption = new MhtLoadOptions();

    // Create a new instance of the Document class and load the MHTML file.
    $document = new Document($inputFile, $loadOption);

    // Save the document as a PDF file.
    $document->save($outputFile);
} catch (Exception $ex) {
    // If an exception occurs, encode the exception message as JSON and echo it.
    echo json_encode($ex);
}

// Generate a response message indicating the successful conversion and the size of the output file.
$responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile);

// Encode the response message as JSON and echo it.
echo '{"message":"' . $responseData . '"}' . PHP_EOL;