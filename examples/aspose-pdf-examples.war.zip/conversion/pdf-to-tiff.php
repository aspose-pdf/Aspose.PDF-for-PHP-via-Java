<?php

/**
 * PDF to TIFF Converter
 *
 * This script converts a PDF document to a TIFF image using the Aspose.PDF for Java library.
 * It utilizes the Java.inc library to interact with Java classes in PHP.
 * The converted TIFF image is saved to the specified output file.
 */
 
// Include the required libraries
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the Aspose.PDF for Java library
use com\aspose\pdf\Document;
use com\aspose\pdf\devices_Resolution;
use com\aspose\pdf\devices_TiffDevice;
use com\aspose\pdf\devices_TiffSettings;
use com\aspose\pdf\devices_CompressionType;
use com\aspose\pdf\devices_ColorDepth;
use com\aspose\pdf\devices_ShapeType;
use com\aspose\pdf\License;

// Set the path to the Aspose.PDF for Java license file
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new License object and set the license file
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the input PDF file
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.pdf";

// Set the path to the output TIFF file
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-pdf-to-tiff.tif';

// Set the response content type to JSON
header('Content-Type: application/json; charset=utf-8');

// Initialize the response data variable
$responseData = "";

try {
    // Create a new Document object from the input PDF file    
    $document = new Document($inputFile);

    // Create a new TiffSettings object
    $tiffSettings = new devices_TiffSettings();

    // Set the resolution for the TIFF image
    $resolution = new devices_Resolution(300);

    // Create a new TiffDevice object with the specified resolution and settings
    $tiffDevice = new devices_TiffDevice($resolution, $tiffSettings);

    // Convert the PDF document to TIFF using the TiffDevice
    $tiffDevice->process($document, 1, 1, $outputFile);

    // Set the response data with the success message and the file size of the converted TIFF image
    $responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile); 

    // Return the response data as a JSON string
    echo '{"message":"' . $responseData . '"}' . PHP_EOL;
} catch (Exception $ex) {
    // If an exception occurs, return the exception as a JSON string
    echo json_encode($ex);
}
