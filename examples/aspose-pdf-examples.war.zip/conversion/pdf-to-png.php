<?php

/**
 * This code demonstrates how to convert a PDF document to PNG images using the Aspose.PDF for PHP library.
 */

// Include the required libraries
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the Aspose.PDF namespace
use com\aspose\pdf\Document;
use com\aspose\pdf\devices_Resolution;
use com\aspose\pdf\devices_PngDevice;
use com\aspose\pdf\License;

// Set the path to the Aspose.PDF license file
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new instance of the License class and set the license file
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the input PDF file
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.pdf";

// Set the template for the output image file names
$imageFileNameTemplate = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-pdf-to-png-';

// Set the response header
header('Content-Type: application/json; charset=utf-8');

// Initialize the response data variable
$responseData = "";

try {
    // Load the PDF document
    $document = new Document($inputFile);

    // Get the collection of pages in the document
    $pages = $document->getPages();

    // Get the total number of pages in the document
    $count = $pages->size();

    // Set the resolution for the PNG images
    $resolution = new devices_Resolution(300);

    // Create a new PNG device with the specified resolution
    $imageDevice = new devices_PngDevice($resolution);

    // Loop through each page in the document
    for ($pageCount = 1; $pageCount <= $document->getPages()->size(); $pageCount++) {
        // Set the output image file name for the current page
        $imageFileName = $imageFileNameTemplate . $pageCount . '.png';

        // Get the current page from the collection
        $page = $document->getPages()->get_Item($pageCount);

        // Process the current page and save it as a PNG image
        $imageDevice->process($page, $imageFileName);

        // Append the image file name and its file size to the response data
        $responseData = "Document has been converted successfully. Filesize: " . filesize($imageFileName);
    }
} catch (Exception $ex) {
    // If an exception occurs, encode the exception message as JSON and echo it
    echo json_encode($ex);
}

// Encode the response data as JSON and echo it
echo '{"message":"' . $responseData . '"}' . PHP_EOL;