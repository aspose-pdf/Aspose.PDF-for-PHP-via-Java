<?php

/**
 * This script demonstrates how to convert a PDF document to EPUB format using the Aspose.PDF for PHP library.
 * It requires the Aspose.PDF for Java library and a valid license file to work.
 */

// Include the required libraries
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the Aspose.PDF for PHP library
use com\aspose\pdf\Document;
use com\aspose\pdf\EpubSaveOptions;
use com\aspose\pdf\License;

// Set the path to the Aspose.PDF for PHP license file
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new instance of the License class and set the license file
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the input PDF file
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.pdf";

// Set the path to the output EPUB file
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-pdf-to-epub.epub';

// Set the response header to indicate JSON content
header('Content-Type: application/json; charset=utf-8');

try {
    // Create a new instance of the Document class and load the input PDF file
    $document = new Document($inputFile);

    // Create a new instance of the EpubSaveOptions class
    $saveOption = new EpubSaveOptions();

    // Save the document as EPUB format using the specified save options
    $document->save($outputFile, $saveOption);
} catch (Exception $ex) {
    // If an exception occurs, encode the exception message as JSON and echo it
    echo json_encode($ex);
}

// Generate the response message
$responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile);

// Echo the response message as JSON
echo '{"message":"' . $responseData . '"}' . PHP_EOL;