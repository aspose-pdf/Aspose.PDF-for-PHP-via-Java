<?php

/**
 * This code demonstrates the usage of the Aspose.PDF for Java library to convert a PDF document to an Excel file.
 * It utilizes the com.aspose.pdf.Document class and the com.aspose.pdf.ExcelSaveOptions class.
 * The code also includes the usage of the Aspose.PDF for Java license.
 */

// Include the required Java.inc file and the Aspose.PDF for Java library file.
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the Aspose.PDF for Java library.
use com\aspose\pdf\Document;
use com\aspose\pdf\ExcelSaveOptions;
use com\aspose\pdf\ExcelSaveOptions_ExcelFormat;
use com\aspose\pdf\License;

// Set the path to the Aspose.PDF for Java license file.
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new instance of the License class and set the license file.
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the input PDF file and the output Excel file.
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.pdf";
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'sample.xlsx';

// Set the response header to indicate that the response will be in JSON format.
header('Content-Type: application/json; charset=utf-8');

try {
    // Load the input PDF document using the Document class.
    $document = new Document($inputFile);

    // Create an instance of the ExcelSaveOptions class to specify the save options.
    $saveOption = new ExcelSaveOptions();

    // Set the output format to XLSX.
    $excelSaveOptions_ExcelFormat = new ExcelSaveOptions_ExcelFormat();
    //$saveOption->setFormat($excelSaveOptions_ExcelFormat->$XMLSpreadSheet2003);

    // Save the PDF document as an Excel file using the specified save options.
    $document->save($outputFile, $saveOption);

    // Generate the response data to indicate the success of the conversion and the file size of the output file.
    $responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile);

} catch (Exception $ex) {
    // If an exception occurs, encode the exception message as JSON and echo it.
    echo json_encode($ex);
}

    // Echo the response data as a JSON string.
$responseData = '{"message":"' . $responseData . '"}' . PHP_EOL;

echo $responseData;
