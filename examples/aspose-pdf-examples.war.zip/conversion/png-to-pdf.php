<?php

/**
 * Convert PNG to PDF
 *
 * This script converts a PNG image file to a PDF document using the Aspose.PDF for PHP library.
 * It utilizes the com\aspose\pdf\Document and com\aspose\pdf\Image classes from the library.
 * The converted PDF document is saved to the specified output file.
 */

// Include the required libraries
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes
use com\aspose\pdf\Document;
use com\aspose\pdf\Image;
use com\aspose\pdf\License;

// Set the license file path
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new License object and set the license
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the data directory path
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";

// Set the input and output file paths
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.png";
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-png-to-pdf.pdf';

// Set the response content type
header('Content-Type: application/json; charset=utf-8');

try {
    // Create a new Document object
    $document = new Document();

    // Add a new page to the document
    $page = $document->getPages()->add();

    // Set the page margins to 0
    $page->getPageInfo()->getMargin()->setBottom(0);
    $page->getPageInfo()->getMargin()->setTop(0);
    $page->getPageInfo()->getMargin()->setRight(0);
    $page->getPageInfo()->getMargin()->setLeft(0);

    // Create a new Image object and set the input file
    $image = new Image();
    $image->setFile($inputFile);

    // Add the image to the page
    $page->getParagraphs()->add($image);

    // Save the document to the output file
    $document->save($outputFile);
    // Prepare the response data
    $responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile);
    // Output the response data as JSON
    echo '{"message":"' . $responseData . '"}' . PHP_EOL;
} catch (Exception $ex) {
    // Handle any exceptions and output the error message
    echo json_encode($ex);
}


