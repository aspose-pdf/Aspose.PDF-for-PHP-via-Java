<?php

/**
 * This code demonstrates how to convert a PDF document to a PowerPoint presentation (PPTX) using  <a class="is-link" href="/AsposePdfExamples/">Aspose.PDF for PHP via Java</a>.
 */

// Include the required Java and Aspose.PDF for PHP libraries
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the Aspose.PDF for PHP library
use com\aspose\pdf\Document;
use com\aspose\pdf\PptxSaveOptions;
use com\aspose\pdf\License;

// Set the path to the Aspose.PDF license file
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new License object and set the license file
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the input PDF file
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.pdf";

// Set the path to the output PPTX file
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-pdf-to-pptx.pptx';

// Set the response header to indicate JSON content
header('Content-Type: application/json; charset=utf-8');

try {
    // Load the input PDF document
    $document = new Document($inputFile);

    // Create an instance of PptxSaveOptions
    $saveOption = new PptxSaveOptions();

    // Save the PDF document as a PPTX file
    $document->save($outputFile, $saveOption);
} catch (Exception $ex) {
    // If an exception occurs, return the exception details as JSON
    echo json_encode($ex);
}

// Prepare the response data
$responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile);

// Return the response data as JSON
echo '{"message":"' . $responseData . '"}' . PHP_EOL;