<?php

/**
 * Convert HTML to PDF using  <a class="is-link" href="/AsposePdfExamples/">Aspose.PDF for PHP via Java</a>.
 *
 * This script demonstrates how to convert an HTML file to PDF using the Aspose.PDF library for PHP via Java.
 * It requires the Aspose.PDF for Java library and a valid license file to be present.
 * The converted PDF file is saved to the specified output file path.
 */

// Include the required libraries
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the Aspose.PDF library
use com\aspose\pdf\Document;
use com\aspose\pdf\HtmlLoadOptions;
use com\aspose\pdf\License;
use com\aspose\pdf\HtmlMediaType;

// Set the path to the Aspose.PDF license file
$licensePath = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new License object and set the license file
$license = new License();
$license->setLicense($licensePath);

// Set the path to the input HTML file
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.html";

// Set the path to the output PDF file
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-html-to-pdf.pdf';

// Set the response header to indicate JSON content
header('Content-Type: application/json; charset=utf-8');

try {
    // Create an instance of HtmlLoadOptions to specify the load options for the HTML file
    $loadOption = new HtmlLoadOptions();
    
    $htmlMediaType = new HtmlMediaType();
    // Set Print or Screen mode
    $loadOption->setHtmlMediaType($htmlMediaType->Print);
    
    // Create a new Document object and load the HTML file
    $document = new Document($inputFile, $loadOption);

    // Save the document as a PDF file
    $document->save($outputFile);
    // Generate a response message indicating the successful conversion and the filesize of the output PDF file
    $responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile);

    // Return the response message as JSON
    echo '{"message":"' . $responseData . '"}' . PHP_EOL;
} catch (Exception $ex) {
    // If an exception occurs, return the exception message as JSON
    echo json_encode($ex);
}

