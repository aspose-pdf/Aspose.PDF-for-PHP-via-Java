<?php

/**
 * This script converts an EPUB file to PDF using the Aspose.PDF library.
 * It requires the Aspose.PDF library and a valid license file.
 */

// Include the required Java bridge and Aspose.PDF library
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the Aspose.PDF library
use com\aspose\pdf\Document;
use com\aspose\pdf\EpubLoadOptions;
use com\aspose\pdf\License;

// Set the path to the Aspose.PDF license file
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new License object and set the license file
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the input EPUB file
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.epub";

// Set the path to the output PDF file
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-epub-to-pdf.pdf';

// Set the response header to indicate JSON content
header('Content-Type: application/json; charset=utf-8');

try {
    // Create a new instance of EpubLoadOptions
    $loadOption = new EpubLoadOptions();

    // Create a new Document object and load the EPUB file
    $document = new Document($inputFile, $loadOption);

    // Save the document as a PDF file
    $document->save($outputFile);
} catch (Exception $ex) {
    // If an exception occurs, return the error message as JSON
    echo json_encode($ex);
}

// Generate the response message with the file size of the converted PDF
$responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile);

// Return the response message as JSON
echo '{"message":"' . $responseData . '"}' . PHP_EOL;