<?php

/**
 * This script converts a PDF document to a series of BMP images using the Aspose.PDF library.
 * It requires a valid license file to be set in order to work properly.
 * The converted images are saved in the specified directory.
 */

// Include the required files from the Aspose.PDF library
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the Aspose.PDF namespace
use com\aspose\pdf\License;
use com\aspose\pdf\Document;
use com\aspose\pdf\devices_Resolution;
use com\aspose\pdf\devices_BmpDevice;

// Set the path to the Aspose.PDF license file
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new License object and set the license file
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the directory where the PDF document and converted images are located
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";

// Set the input PDF file path
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.pdf";

// Set the image file name template for the converted BMP images
$imageFileNameTemplate = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-pdf-to-bmp-';

// Set the response content type to JSON
header('Content-Type: application/json; charset=utf-8');

// Initialize the response data variable
$responseData = "";

try {
    // Create a new Document object from the input PDF file
    $document = new Document($inputFile);

    // Get the collection of pages in the document
    $pages = $document->getPages();

    // Get the total number of pages in the document
    $count = $pages->size();

    // Set the resolution for the image conversion
    $resolution = new devices_Resolution(300);

    // Create a new BMP device for the image conversion
    $imageDevice = new devices_BmpDevice($resolution);

    // Iterate over each page in the document
    for ($pageCount = 1; $pageCount <= $document->getPages()->size(); $pageCount++) {
        // Set the image file name for the current page
        $imageFileName = $imageFileNameTemplate . $pageCount . '.bmp';

        // Get the current page from the collection
        $page = $document->getPages()->get_Item($pageCount);

        // Process the current page and save the converted image
        $imageDevice->process($page, $imageFileName);

        // Append a success message to the response data
        $responseData = "Document has been converted successfully. Filesize: " . filesize($imageFileName);
    }
} catch (Exception $ex) {
    // If an exception occurs, encode the exception message as JSON and echo it
    $responseData = json_encode($ex);
}



// Encode the response data as JSON and echo it
echo '{"message":"' . $responseData . '"}' . PHP_EOL;