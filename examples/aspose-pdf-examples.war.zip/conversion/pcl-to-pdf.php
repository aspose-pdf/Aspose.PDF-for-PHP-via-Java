<?php

/**
 * This code demonstrates how to convert a PCL file to PDF using the  <a class="is-link" href="/AsposePdfExamples/">Aspose.PDF for PHP via Java</a> library.
 */

// Include the required libraries
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the  <a class="is-link" href="/AsposePdfExamples/">Aspose.PDF for PHP via Java</a> library
use com\aspose\pdf\Document;
use com\aspose\pdf\PclLoadOptions;
use com\aspose\pdf\License;

// Set the path to the Aspose.PDF.PHPviaJava license file
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new License object and set the license file
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the input and output files
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.prn";
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-pcl-to-pdf.pdf';

// Set the response header
header('Content-Type: application/json; charset=utf-8');

try {    
    // Create a new instance of PclLoadOptions
    $loadOption = new PclLoadOptions();

    // Create a new instance of Document and load the PCL file
    $document = new Document($inputFile, $loadOption);

    // Save the document as a PDF file
    $document->save($outputFile);
} catch (Exception $ex) {
    // If an exception occurs, echo the exception message as JSON
    echo json_encode($ex);
}

// Generate the response data
$responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile);

// Echo the response data as JSON
echo '{"message":"' . $responseData . '"}' . PHP_EOL;