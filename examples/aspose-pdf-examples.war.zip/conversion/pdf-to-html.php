<?php

/**
 * PDF to HTML Converter
 *
 * This script converts a PDF document to HTML using the Aspose.PDF for PHP library.
 * It requires the Aspose.PDF for Java library and a valid license file to function properly.
 * The converted HTML file is saved to the specified output directory.
 */
 
// Include the required libraries
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the Aspose.PDF library
use com\aspose\pdf\Document;
use com\aspose\pdf\HtmlSaveOptions;
use com\aspose\pdf\License;

// Set the path to the license file
$licensePath = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new License object and set the license using the provided file path
$license = new License();
$license->setLicense($licensePath);

// Set the path to the input PDF file
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.pdf";

// Set the path to the output HTML file
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-pdf-to-html.html';

// Set the response content type to JSON
header('Content-Type: application/json; charset=utf-8');

try {
    // Create a new Document object and load the input PDF file
    $document = new Document($inputFile);
    
    // Create a new HtmlSaveOptions object for saving the document as HTML
    $saveOption = new HtmlSaveOptions();
    
    // Save the document as HTML using the specified save options
    $document->save($outputFile, $saveOption);
} catch (Exception $ex) {
    // If an exception occurs, return the exception details as JSON
    echo json_encode($ex);
}

// Generate the response data
$responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile);

// Return the response data as JSON
echo '{"message":"' . $responseData . '"}' . PHP_EOL;