<?php

/**
 * This script demonstrates how to convert a PDF document to LaTeX using  <a class="is-link" href="/AsposePdfExamples/">Aspose.PDF for PHP via Java</a>.
 * It requires the Aspose.PDF for Java library and a valid license file.
 */

// Include the required Java and Aspose.PDF for PHP libraries
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the Aspose.PDF for PHP library
use com\aspose\pdf\Document;
use com\aspose\pdf\LaTeXSaveOptions;
use com\aspose\pdf\License;

// Set the path to the  <a class="is-link" href="/AsposePdfExamples/">Aspose.PDF for PHP via Java</a> license file
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new License object and set the license file
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the input PDF file
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.pdf";

// Set the path to the output LaTeX file
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-pdf-to-latex.tex';

// Set the response header to indicate JSON content
header('Content-Type: application/json; charset=utf-8');

try {
    // Create a new Document object and load the input PDF file
    $document = new Document($inputFile);

    // Create a new LaTeXSaveOptions object
    $saveOption = new LaTeXSaveOptions();

    // Save the document as LaTeX
    $document->save($outputFile, $saveOption);
} catch (Exception $ex) {
    // If an exception occurs, encode the exception message as JSON and echo it
    echo json_encode($ex);
}

// Generate a response message indicating the successful conversion and the size of the output file
$responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile);

// Echo the response message as JSON
echo '{"message":"' . $responseData . '"}' . PHP_EOL;