<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Aspose.PDF for PHP via Java</title>
    <link rel="stylesheet"  href="https://cdn.jsdelivr.net/npm/bulma@1.0.0/css/bulma.min.css">
    <style>
        .fix-size {
            width: 100%;
        }
    </style>
    <script src="../script.js"></script>
</head>

<body>
    <section class="section">
        <div class="container">
            <h1 class="title">
                 <a class="is-link" href="/AsposePdfExamples/">Aspose.PDF for PHP via Java</a>
            </h1>
            <p class="subtitle">
                Examples for Tomcat
            </p>
        </div>
        <div class="container">
            <div class="table-container">
                <table class="table fix-size">
                    <thead>
                        <tr>
                            <th style="width: 30%;">Operation</th>
                            <th style="width: 70%;">Result</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <button class="button fix-size is-responsive" 
                                    data-url="bmp-to-pdf">
                                    Convert BMP to PDF
                                </button>
                            </td>
                            <td>
                                <output id="bmp-to-pdf">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="cgm-to-pdf">
                                    Convert CGM to PDF
                                </button>
                            </td>
                            <td>
                                <output id="cgm-to-pdf">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="dicom-to-pdf">
                                    Convert DICOM to PDF
                                </button>
                            </td>
                            <td>
                                <output id="dicom-to-pdf">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="emf-to-pdf">
                                    Convert EMF to PDF</button>
                            </td>
                            <td>
                                <output id="emf-to-pdf">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="epub-to-pdf">
                                    Convert EPUB to PDF
                                </button>
                            </td>
                            <td>
                                <output id="epub-to-pdf">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="html-to-pdf">
                                    Convert HTML to PDF
                                </button>
                            </td>
                            <td>
                                <output id="html-to-pdf">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="jpg-to-pdf"> 
                                    Convert JPEG to PDF
                                </button>
                            </td>
                            <td>
                                <output id="jpg-to-pdf">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="latex-to-pdf">
                                    Convert LaTeX to PDF</button>
                            </td>
                            <td>
                                <output id="latex-to-pdf">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="md-to-pdf">
                                    Convert Markdown to PDF
                                </button>
                            </td>
                            <td>
                                <output id="md-to-pdf">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="mhtml-to-pdf"> Convert
                                    MHTML to
                                    PDF</button>
                            </td>
                            <td>
                                <output id="mhtml-to-pdf">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="pcl-to-pdf"> Convert
                                    PCL to
                                    PDF</button>
                            </td>
                            <td>
                                <output id="pcl-to-pdf">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="pdfa-to-pdf"> Convert
                                    PDF/A
                                    to
                                    PDF</button>
                            </td>
                            <td>
                                <output id="pdfa-to-pdf">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="pdf-to-bmp"> Convert
                                    PDF to
                                    BMP</button>
                            </td>
                            <td>
                                <output id="pdf-to-bmp">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="pdf-to-docx"> Convert
                                    PDF
                                    to
                                    DOCX</button>
                            </td>
                            <td>
                                <output id="pdf-to-docx">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="pdf-to-epub"> Convert
                                    PDF
                                    to
                                    EPUB</button>
                            </td>
                            <td>
                                <output id="pdf-to-epub">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="pdf-to-html"> Convert
                                    PDF
                                    to
                                    HTML</button>
                            </td>
                            <td>
                                <output id="pdf-to-html">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="pdf-to-jpeg"> Convert
                                    PDF
                                    to
                                    JPEG</button>
                            </td>
                            <td>
                                <output id="pdf-to-jpeg">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="pdf-to-latex"> Convert
                                    PDF
                                    to
                                    LaTeX</button>
                            </td>
                            <td>
                                <output id="pdf-to-latex">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="pdf-to-mobixml"> Convert
                                    PDF to
                                    Mobi</button>
                            </td>
                            <td>
                                <output id="pdf-to-mobixml">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="pdf-to-pdfa"> Convert
                                    PDF
                                    to
                                    PDF/A</button>
                            </td>
                            <td>
                                <output id="pdf-to-pdfa">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="pdf-to-png"> Convert
                                    PDF to
                                    PNG</button>
                            </td>
                            <td>
                                <output id="pdf-to-png">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="pdf-to-pptx"> Convert
                                    PDF
                                    to
                                    PowerPoint</button>
                            </td>
                            <td>
                                <output id="pdf-to-pptx">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="pdf-to-svg"> Convert
                                    PDF to
                                    SVG</button>
                            </td>
                            <td>
                                <output id="pdf-to-svg">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="pdf-to-tiff">
                                    Convert PDF to TIFF
                                </button>
                            </td>
                            <td>
                                <output id="pdf-to-tiff">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="pdf-to-txt"> Convert
                                    PDF to
                                    TXT</button>
                            </td>
                            <td>
                                <output id="pdf-to-txt">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="pdf-to-xlsx"> Convert
                                    PDF
                                    to
                                    Excel</button>
                            </td>
                            <td>
                                <output id="pdf-to-xlsx">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="pdf-to-xml"> Convert
                                    PDF to
                                    XML</button>
                            </td>
                            <td>
                                <output id="pdf-to-xml">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="pdf-to-xps"> Convert
                                    PDF to
                                    XPS</button>
                            </td>
                            <td>
                                <output id="pdf-to-xps">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="png-to-pdf"> Convert
                                    PNG to
                                    PDF</button>
                            </td>
                            <td>
                                <output id="png-to-pdf">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="postscript-to-pdf"> Convert
                                    PostScript to PDF</button>
                            </td>
                            <td>
                                <output id="postscript-to-pdf">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="svg-to-pdf"> Convert
                                    SVG to
                                    PDF</button>
                            </td>
                            <td>
                                <output id="svg-to-pdf">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="text-to-pdf"> Convert
                                    Text
                                    to
                                    PDF</button>
                            </td>
                            <td>
                                <output id="text-to-pdf">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="tiff-to-pdf"> Convert
                                    TIFF
                                    to
                                    PDF</button>
                            </td>
                            <td>
                                <output id="tiff-to-pdf">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="xmlfo-to-pdf"> Convert
                                    XML-FO
                                    to PDF</button>
                            </td>
                            <td>
                                <output id="xmlfo-to-pdf">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td><button class="button fix-size is-responsive" 
                                    data-url="xps-to-pdf"> Convert
                                    XPS to
                                    PDF</button>
                            </td>
                            <td>
                                <output id="xps-to-pdf">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</body>

</html>