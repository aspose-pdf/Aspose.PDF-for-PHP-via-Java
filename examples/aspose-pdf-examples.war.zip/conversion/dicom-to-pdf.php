<?php

/**
 * This code demonstrates the conversion of a DICOM image to a PDF document using the Aspose.PDF for PHP library.
 * It utilizes the com\aspose\pdf\Document and com\aspose\pdf\Image classes from the library.
 */
 
// Include the required Java bridge and Aspose.PDF library files
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the Aspose.PDF library
use com\aspose\pdf\Document;
use com\aspose\pdf\Image;
use com\aspose\pdf\ImageFileType;
use com\aspose\pdf\License;

// Set the path to the Aspose.PDF license file
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new License object and set the license file
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the input DICOM file and the output PDF file
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.dcm";
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-dcm-to-pdf.pdf';

// Set the response header to indicate JSON content
header('Content-Type: application/json; charset=utf-8');

try {
    // Create a new Document object
    $document = new Document();

    // Add a new page to the document
    $page = $document->getPages()->add();

    // Set the margins of the page to 0
    $page->getPageInfo()->getMargin()->setBottom(0);
    $page->getPageInfo()->getMargin()->setTop(0);
    $page->getPageInfo()->getMargin()->setRight(0);
    $page->getPageInfo()->getMargin()->setLeft(0);
    
    // Create a new Image object
    $image = new Image();

    // Set the DICOM file as the source file for the image
    $image->setFile($inputFile);

    // Set the file type of the image to DICOM
    $imageFileType = new ImageFileType();
    $image->setFileType($imageFileType->Dicom);

    // Add the image to the page
    $page->getParagraphs()->add($image);

    // Save the document as a PDF file
    $document->save($outputFile);
} catch (Exception $ex) {
    // If an exception occurs, encode the exception message as JSON and echo it
    echo json_encode($ex);
}

// Generate the response data
$responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile);

// Echo the response data as JSON
echo '{"message":"' . $responseData . '"}' . PHP_EOL;
?>