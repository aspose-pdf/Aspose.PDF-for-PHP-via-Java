<?php

/**
 * This script demonstrates how to convert an EMF file to PDF using the  <a class="is-link" href="/AsposePdfExamples/">Aspose.PDF for PHP via Java</a> library.
 * It utilizes the com.aspose.pdf.Document and com.aspose.pdf.Image classes to perform the conversion.
 */

// Include the necessary libraries
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the required classes from the  <a class="is-link" href="/AsposePdfExamples/">Aspose.PDF for PHP via Java</a> library
use com\aspose\pdf\Document;
use com\aspose\pdf\Image;
use com\aspose\pdf\License;

// Set the path to the Aspose.PDF license file
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new License object and set the license file
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the input EMF file
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.emf";

// Set the path to the output PDF file
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-emf-to-pdf.pdf';

// Set the response header
header('Content-Type: application/json; charset=utf-8');

try {
    // Create a new Document object
    $document = new Document();

    // Add a new page to the document
    $page = $document->getPages()->add();

    // Set the margins of the page to 0
    $page->getPageInfo()->getMargin()->setBottom(0);
    $page->getPageInfo()->getMargin()->setTop(0);
    $page->getPageInfo()->getMargin()->setRight(0);
    $page->getPageInfo()->getMargin()->setLeft(0);

    // Create a new Image object and set the input file
    $image = new Image();
    $image->setFile($inputFile);

    // Add the image to the page
    $page->getParagraphs()->add($image);

    // Save the document as a PDF file
    $document->save($outputFile);
} catch (Exception $ex) {
    // Handle any exceptions that occur during the conversion process
    echo json_encode($ex);
}

// Generate the response message
$responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile);

// Return the response message as JSON
echo '{"message":"' . $responseData . '"}' . PHP_EOL;