<?php

/**
 * This code demonstrates how to convert a TIFF image to a PDF document using the  <a class="is-link" href="/AsposePdfExamples/">Aspose.PDF for PHP via Java</a> library.
 * It utilizes the com.aspose.pdf.Document and com.aspose.pdf.Image classes to perform the conversion.
 */
 
// Include the required libraries
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the  <a class="is-link" href="/AsposePdfExamples/">Aspose.PDF for PHP via Java</a> library
use com\aspose\pdf\Document;
use com\aspose\pdf\Image;
use com\aspose\pdf\License;

// Set the path to the Aspose.PDF license file
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new License object and set the license file
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the input TIFF file and the output PDF file
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.tiff";
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-tiff-to-pdf.pdf';

// Set the response header
header('Content-Type: application/json; charset=utf-8');

try {
    // Create a new Document object
    $document = new Document();
    
    // Add a new page to the document
    $page = $document->getPages()->add();
    
    // Set the margins of the page to 0
    $page->getPageInfo()->getMargin()->setBottom(0);
    $page->getPageInfo()->getMargin()->setTop(0);
    $page->getPageInfo()->getMargin()->setRight(0);
    $page->getPageInfo()->getMargin()->setLeft(0);

    // Create a new Image object
    $image = new Image();
    
    // Set the file path of the input TIFF image
    $image->setFile($inputFile);
    
    // Add the image to the page
    $page->getParagraphs()->add($image);

    // Save the document as a PDF file
    $document->save($outputFile);
    
    // Get the file size of the output PDF file
    $fileSize = filesize($outputFile);
    
    // Create the response data
    $responseData = "Document has been converted successfully. Filesize: " . $fileSize;
    
    // Return the response data as JSON
    echo '{"message":"' . $responseData . '"}' . PHP_EOL;
} catch (Exception $ex) {
    // If an exception occurs, return the exception as JSON
    echo json_encode($ex);
}
