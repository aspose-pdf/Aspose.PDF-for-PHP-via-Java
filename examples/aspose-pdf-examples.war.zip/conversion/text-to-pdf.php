<?php

/**
 * This script converts a text file to PDF using the Aspose.PDF library.
 * It reads the content of a text file, creates a PDF document, and adds the text to the document.
 * The resulting PDF file is saved to the specified output file path.
 */

// Include the required Aspose.PDF classes and the Java bridge.
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary Aspose.PDF classes.
use com\aspose\pdf\Document;
use com\aspose\pdf\TextFragment;
use com\aspose\pdf\License;
use com\aspose\pdf\FontRepository;

// Set the license file path.
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new License object and set the license using the file path.
$licenceObject = new License();
$licenceObject->setLicense($license);

// Define the input and output file paths.
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.txt";
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-txt-to-pdf.pdf';

// Set the response header to indicate JSON content.
header('Content-Type: application/json; charset=utf-8');

try {
    // Create a new Document object.
    $document = new Document();

    // Add a new page to the document.
    $page = $document->getPages()->add();

    // Read the content of the input text file.
    $text = file_get_contents($inputFile);

    // Create a new FontRepository object.
    $fontRepository = new FontRepository();

    // Find the "Courier" font in the repository.
    $font = $fontRepository->findFont("Courier");

    // Create a new TextFragment object with the input text.
    $textFragment = new TextFragment($text);

    // Set the font of the text fragment to "Courier".
    $textFragment->getTextState()->setFont($font);

    // Add the text fragment to the page.
    $page->getParagraphs()->add($textFragment);

    // Save the document to the output file.
    $document->save($outputFile);

    // Generate the response message.
    $responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile);
    
    // Echo the response message as JSON.
    echo '{"message":"' . $responseData . '"}' . PHP_EOL;
} catch (Exception $ex) {
    // If an exception occurs, encode the exception as JSON and echo it.
    echo json_encode($ex);
}
