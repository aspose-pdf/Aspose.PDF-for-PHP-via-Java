<?php

/**
 * This code demonstrates how to convert a PDF/A document to a regular PDF document using the Aspose.PDF library.
 */

// Include the necessary libraries
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the required classes from the Aspose.PDF library
use com\aspose\pdf\Document;

// Set the directory path for the input and output files
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";

// Set the path of the input PDF/A file
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample-pdfa.pdf";

// Set the path of the output PDF file
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-pdfa-to-pdf.pdf';

// Set the response header to indicate JSON content
header('Content-Type: application/json; charset=utf-8');

// Create a new instance of the Document class with the input file
$document = new Document($inputFile);

// Remove the PDF/A compliance from the document
$document->removePdfaCompliance();

// Save the modified document to the output file
$document->save($outputFile);

// Prepare the response data
$responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile);

// Echo the response data in JSON format
echo '{"message":"' . $responseData . '"}' . PHP_EOL;