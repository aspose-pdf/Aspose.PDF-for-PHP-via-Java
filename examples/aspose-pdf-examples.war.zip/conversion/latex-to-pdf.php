<?php

/**
 * This script demonstrates how to convert a TeX file to PDF using the  <a class="is-link" href="/AsposePdfExamples/">Aspose.PDF for PHP via Java</a> library.
 */

// Include the required Java and Aspose.PDF for PHP libraries
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the Aspose.PDF for PHP library
use com\aspose\pdf\Document;
use com\aspose\pdf\LatexLoadOptions;
use com\aspose\pdf\License;

// Set the path to the  <a class="is-link" href="/AsposePdfExamples/">Aspose.PDF for PHP via Java</a> license file
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new instance of the License class and set the license file
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the directory containing the TeX file and the output PDF file
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.tex";
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-tex-to-pdf.pdf';

// Set the response header to indicate that the response will be in JSON format
header('Content-Type: application/json; charset=utf-8');

try {    
    // Create a new instance of the LatexLoadOptions class
    $loadOption = new LatexLoadOptions();
    
    // Create a new instance of the Document class and load the TeX file using the TeXLoadOptions
    $document = new Document($inputFile, $loadOption);
    
    // Save the document as a PDF file
    $document->save($outputFile);
} catch (Exception $ex) {
    // If an exception occurs, encode the exception message as JSON and echo it
    echo json_encode($ex);
}

// Create a response message indicating the successful conversion and the size of the output PDF file
$responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile);

// Echo the response message as JSON
echo '{"message":"' . $responseData . '"}' . PHP_EOL;