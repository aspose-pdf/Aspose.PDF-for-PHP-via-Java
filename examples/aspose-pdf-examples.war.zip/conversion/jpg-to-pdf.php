<?php

/**
 * Convert JPG to PDF
 *
 * This script converts a JPG image file to a PDF document using the Aspose.PDF for PHP library.
 * It utilizes the com\aspose\pdf\Document and com\aspose\pdf\Image classes from the library.
 * The resulting PDF document is saved to the specified output file.
 */
 
// Include the required Java bridge and Aspose.PDF for PHP library files
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the Aspose.PDF for PHP library
use com\aspose\pdf\Document;
use com\aspose\pdf\Image;
use com\aspose\pdf\License;

// Set the path to the Aspose.PDF license file
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new License object and set the license file
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the directory containing the input and output files
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";

// Set the input and output file paths
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.jpg";
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-jpg-to-pdf.pdf';

// Set the response header to indicate JSON content
header('Content-Type: application/json; charset=utf-8');

try {
    // Create a new Document object
    $document = new Document();

    // Add a new page to the document
    $page = $document->getPages()->add();

    // Set the margins of the page to 0
    $page->getPageInfo()->getMargin()->setBottom(0);
    $page->getPageInfo()->getMargin()->setTop(0);
    $page->getPageInfo()->getMargin()->setRight(0);
    $page->getPageInfo()->getMargin()->setLeft(0);
    
    // Create a new Image object and set the input file
    $image = new Image();
    $image->setFile($inputFile);

    // Add the image to the page
    $page->getParagraphs()->add($image);

    // Save the document to the output file
    $document->save($outputFile);
} catch (Exception $ex) {
    // If an exception occurs, encode the exception message as JSON and echo it
    echo json_encode($ex);
}

// Generate the response data
$responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile);

// Echo the response data as JSON
echo '{"message":"' . $responseData . '"}' . PHP_EOL;
