<?php

/**
 * This code demonstrates the usage of the Aspose.PDF for Java library to convert an SVG file to PDF.
 * The code utilizes the Java.inc library to interact with the Java code from PHP.
 * It requires the Aspose.PDF for Java library and a valid license file to run successfully.
 */

// Include the required libraries
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the Aspose.PDF for Java library
use com\aspose\pdf\Document;
use com\aspose\pdf\SvgLoadOptions;
use com\aspose\pdf\License;

// Set the path to the Aspose.PDF license file
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new License object and set the license file
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the input SVG file
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.svg";

// Set the path to the output PDF file
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-svg-to-pdf.pdf';

// Set the response header
header('Content-Type: application/json; charset=utf-8');

try {
    // Create a new SvgLoadOptions object
    $loadOption = new SvgLoadOptions();

    // Create a new Document object and load the SVG file
    $document = new Document($inputFile, $loadOption);

    // Save the document as a PDF file
    $document->save($outputFile);

    // Prepare the response data
    $responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile);

    // Return the response data as JSON
    echo '{"message":"' . $responseData . '"}' . PHP_EOL;
} catch (Exception $ex) {
    // Handle any exceptions and return the error message as JSON
    echo json_encode($ex);
}