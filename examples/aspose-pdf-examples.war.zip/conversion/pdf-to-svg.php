<?php

/**
 * PDF to SVG Converter
 *
 * This script converts a PDF document to SVG format using the Aspose.PDF library.
 * It requires the Aspose.PDF for Java library and a valid license file to run.
 * The converted SVG file is saved to the specified output directory.
 */
 
// Include the required libraries
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the Aspose.PDF library
use com\aspose\pdf\Document;
use com\aspose\pdf\SvgSaveOptions;
use com\aspose\pdf\License;

// Set the path to the Aspose.PDF license file
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new instance of the License class and set the license file
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the input PDF file
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.pdf";

// Set the path to the output SVG file
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-pdf-to-svg.svg';

// Set the response header to indicate JSON content
header('Content-Type: application/json; charset=utf-8');

try {
    // Load the PDF document
    $document = new Document($inputFile);
    
    // Create an instance of the SvgSaveOptions class
    $saveOption = new SvgSaveOptions();
    
    // Save the PDF document as SVG
    $document->save($outputFile, $saveOption);
} catch (Exception $ex) {
    // If an exception occurs, return the error message as JSON
    echo json_encode($ex);
}

// Generate the response message
$responseData = "Document has been converted successfully. Filesize: " . filesize($outputFile);

// Return the response message as JSON
echo '{"message":"' . $responseData . '"}' . PHP_EOL;