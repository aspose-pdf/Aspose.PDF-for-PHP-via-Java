<?php
/**
 * This script demonstrates how to extract form field values from a PDF document using  <a class="is-link" href="/AsposePdfExamples/">Aspose.PDF for PHP via Java</a>.
 */

// Include the required Java and Aspose.PDF for PHP libraries
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the Aspose.PDF for PHP library
use com\aspose\pdf\License;
use com\aspose\pdf\facades_Form;

// Set the path to the Aspose.PDF license file
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new instance of the License class and set the license file
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the directory containing the PDF document
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";

// Set the path to the input PDF file
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "StudentInfoFormElectronic.pdf";

// Set the response header to indicate that the response will be in JSON format
header('Content-Type: application/json; charset=utf-8');

// Initialize the response data variable
$responseData = "";

try {
    // Open document
    $form = new facades_Form();
    $form->bindPdf($inputFile);
    
    // Create a FileOutputStream object to write the font file.
    $xmlOutputStream = new java("java.io.FileOutputStream", "output.xml");
   
    // Export data
    $form->exportXml($xmlOutputStream);

    // Close file stream
    $xmlOutputStream->close();

    // Close the document
    $form->close();   

} catch (Exception $ex) {
    // If an exception occurs, encode the exception message as JSON
    $responseData = json_encode($ex);
}

// Output the response data
echo '{"message":"' . $responseData . '"}' . PHP_EOL;