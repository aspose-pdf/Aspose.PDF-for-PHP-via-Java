<?php

/**
 * This code demonstrates the usage of the Aspose.PDF for Java library in PHP to extract text from a PDF document.
 * It utilizes the com.aspose.pdf.Document class to load the PDF document, com.aspose.pdf.TextAbsorber class to extract text,
 * and com.aspose.pdf.StampAnnotation class to work with stamp annotations.
 */

// Include the required Java classes and the Aspose.PDF for Java library
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary Java classes
use com\aspose\pdf\Document;
use com\aspose\pdf\License;
use com\aspose\pdf\AnnotationSelector;
use com\aspose\pdf\StampAnnotation;
use com\aspose\pdf\TextAbsorber;

// Set the path to the Aspose.PDF license file
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new instance of the License class and set the license file
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the directory containing the PDF file
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";

// Set the path to the input PDF file
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample-stamp.pdf";

// Set the response content type to JSON
header('Content-Type: application/json; charset=utf-8');

// Initialize the response data variable
$responseData = "";

try {
    // Load the PDF document
    $document = new Document($inputFile);

    // Get the first page of the document
    $page = $document->getPages()->get_Item(1);

    // Create a new instance of the StampAnnotation class
    $stampAnnotation = new StampAnnotation($document);

    // Create a new instance of the AnnotationSelector class and pass the stamp annotation to it
    $annotationSelector = new AnnotationSelector($stampAnnotation);

    // Accept the annotation selector on the page
    $page->accept($annotationSelector);

    // Get the selected stamp annotations
    $stampAnnotations = $annotationSelector->getSelected();

    // Create a new instance of the TextAbsorber class
    $textAbsorber = new TextAbsorber();

    // Get the first stamp annotation
    $stampAnnotation = $stampAnnotations->get(0);

    // Get the normal appearance of the stamp annotation
    $appearance = $stampAnnotation->getNormalAppearance();

    // Visit the appearance using the text absorber
    $textAbsorber->visit($appearance);

    // Get the extracted text from the text absorber
    $responseData = java_values($textAbsorber->getText());

    // Close the document
    $document->close();
} catch (Exception $ex) {
    // If an exception occurs, encode the exception message as JSON
    $responseData = json_encode($ex);
}

// Output the response data
echo '{"message":"' . $responseData . '"}' . PHP_EOL;
