<?php

/**
 * This script demonstrates how to convert a PDF document to an image using Aspose.PDF for Java library in PHP.
 */

// Include the necessary libraries
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the required classes from the Aspose.PDF for Java library
use com\aspose\pdf\Document;
use com\aspose\pdf\License;

// Set the path to the Aspose.PDF license file
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new License object and set the license file
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the input PDF file
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.pdf";

// Set the path to the output image file
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-parse-image.jpg';

// Set the response header
header('Content-Type: application/json; charset=utf-8');

try {
    // Load the PDF document
    $document = new Document($inputFile);

    // Get the first page of the document
    $page = $document->getPages()->get_Item(1);

    // Get the collection of images on the page
    $xImageCollection = $page->getResources()->getImages();

    // Get the first image from the collection
    $xImage = $xImageCollection->get_Item(1);

    // Create a new FileOutputStream object to save the image
    $outputImage = new java("java.io.FileOutputStream", $outputFile);

    // Save the image to the output file
    $xImage->save($outputImage);

    // Close the output image file
    $outputImage->close();

    // Prepare the response data
    $responseData = "Image has been extrcated successfully. Filesize: " . filesize($outputFile);
} catch (Exception $ex) {
    // Prepare the response data in case of an exception
    $responseData = json_encode($ex);
}

// Output the response data
echo '{"message":"' . $responseData . '"}' . PHP_EOL;
