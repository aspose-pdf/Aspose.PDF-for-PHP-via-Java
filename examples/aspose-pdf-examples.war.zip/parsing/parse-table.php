<?php

require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");
/**
 * PDFTableParser class
 *
 * This class provides functionalities for parsing tables from a PDF document using the Aspose.PDF library.
 */
use com\aspose\pdf\Document;
use com\aspose\pdf\TableAbsorber;
use com\aspose\pdf\License;

class PDFTableParser
{

    /**
     * Parse tables from a PDF document and save the results to a text file.
     *
     * This function reads a PDF document, extracts tables from each page, and saves the table data to a text file.
     * The function uses the Aspose.PDF library for PDF processing.    
     */
    public function parseTables()
    {
        // Load the Aspose.PDF library and set the license file.

        $license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";
        $licenceObject = new License();
        $licenceObject->setLicense($license);

        // Initialize variables.
        $dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
        $inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.pdf";
        $outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-parse-table.txt';
        $responseData = "";

        try {
            // Open the PDF document.
            $document = new Document($inputFile);
            $pages = $document->getPages();
            // Create a TableAbsorber object to extract tables from the document.
            $tableAbsorber = new TableAbsorber();

            // Iterate through each page of the document.
            for ($pageIndex = 1; $pageIndex <= java_values($pages->size()); $pageIndex++) {
                $page = $pages->get_Item($pageIndex);
                $tableAbsorber->visit($page);
                $tableList = $tableAbsorber->getTableList();
                $tableIterator = $tableList->iterator();

                // Iterate through each table on the page.
                while (java_values($tableIterator->hasNext())) {
                    $table = $tableIterator->next();
                    $tableRowList = $table->getRowList();
                    $tableRowListIterator = $tableRowList->iterator();

                    // Iterate through each row in the table.
                    while (java_values($tableRowListIterator->hasNext())) {
                        $row = $tableRowListIterator->next();
                        $cellList = $row->getCellList();
                        $cellListIterator = $cellList->iterator();

                        // Iterate through each cell in the row.
                        while (java_values($cellListIterator->hasNext())) {
                            $cell = $cellListIterator->next();
                            $fragmentList = $cell->getTextFragments();

                            // Iterate through each text fragment in the cell.
                            for ($fragmentIndex = 1; $fragmentIndex <= java_values($fragmentList->size()); $fragmentIndex++) {
                                $fragment = $fragmentList->get_Item($fragmentIndex);
                                $segments = $fragment->getSegments();

                                // Iterate through each segment in the text fragment.
                                for ($segmentIndex = 1; $segmentIndex <= java_values($segments->size()); $segmentIndex++) {
                                    $segment = $segments->get_Item($segmentIndex);
                                    $responseData .= $segment->getText();
                                }
                            }
                            $responseData .= "|";
                        }
                        $responseData .= PHP_EOL;
                    }
                }
            }

            // Save the table data to the output file.
            file_put_contents($outputFile, $responseData);

            // Return a success message with the file size of the output file.
            $responseData = "Document has been created successfully. Filesize: " . filesize($outputFile);

            // Close the PDF document.
            $document->close();
        } catch (Exception $ex) {
            //     // Return an error message if any exception occurs during the parsing process.
             $responseData = $ex;
        }

        // Return the response message as a JSON-encoded string.
        return '{"message":"' . $responseData . '"}' . PHP_EOL;
    }
}

// Instantiate the PDFTableParser class and call the parseTables method.
$parser = new PDFTableParser();
echo $parser->parseTables();