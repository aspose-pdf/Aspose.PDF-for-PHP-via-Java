<?php

require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

use com\aspose\pdf\Document;
use com\aspose\pdf\TableAbsorber;
use com\aspose\pdf\License;


$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";
$licenceObject = new License();
$licenceObject->setLicense($license);

$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.pdf";
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-parse-table.txt';

header('Content-Type: application/json; charset=utf-8');


$document = new Document($inputFile);
$tableAbsorber = new TableAbsorber();
$pages = $document->getPages();
print_r(java_values($pages));

$responseData = PHP_EOL;
try {
    for ($pageIndex = 1; $pageIndex <= java_values($pages->size()); $pageIndex++) {
        $page = $pages->get_Item($pageIndex);
        $tableAbsorber->visit($page);
        $tableList = $tableAbsorber->getTableList();       
        $tables_count = java_values($tableList->size());
        for ($tableIndex = 0; $tableIndex < java_values($tables_count); $tableIndex++) {
            $table = $tableList->get($tableIndex);
            $tableRowList = $table->getRowList();
            $responseData = $responseData . "Table " . $tableIndex . PHP_EOL;            
            for ($rowIndex = 0; $rowIndex < java_values($tableRowList->size()); $rowIndex++) {
                $row = $tableRowList->get($rowIndex);
                $cellList = $row->getCellList();                
                for ($cellIndex = 0; $cellIndex < java_values($cellList->size()); $cellIndex++) {
                    $cell = $cellList->get($cellIndex);
                    $fragmentList = $cell->getTextFragments();                    
                    for ($fragmentIndex = 1; $fragmentIndex <= java_values($fragmentList->size()); $fragmentIndex++) {
                        $fragment = $fragmentList->get_Item($fragmentIndex);
                        $segments = $fragment->getSegments();                        
                        for ($segmentIndex = 1; $segmentIndex <= java_values($segments->size()); $segmentIndex++) {                            
                            $segment = $segments->get_Item($segmentIndex);      
                            $responseData = $responseData . $segment->getText();
                        }                        
                    }
                    $responseData = $responseData . "|";
                }
                $responseData = $responseData . PHP_EOL;
            }
        }
    }
    file_put_contents($outputFile, $responseData);
    $responseData = "Document has been created successfully. Filesize: " . filesize($outputFile);
    $document->close();
} catch (Exception $ex) {
    $responseData = "Error" . $ex;
}

echo '{"message":"' . $responseData . '"}' . PHP_EOL;