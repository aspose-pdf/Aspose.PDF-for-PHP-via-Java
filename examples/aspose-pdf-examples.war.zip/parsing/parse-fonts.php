<?php

/**
 * This script demonstrates how to extract fonts from a PDF document using the Aspose.PDF for PHP via Java library.
 */

// Include the required files from the Aspose.PDF for PHP via Java library.
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

// Import the necessary classes from the Aspose.PDF for PHP via Java library.
use com\aspose\pdf\Document;
use com\aspose\pdf\License;

// Set the path to the Aspose.PDF license file.
$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";

// Create a new instance of the License class and set the license file.
$licenceObject = new License();
$licenceObject->setLicense($license);

// Set the path to the directory containing the PDF document and the output directory for the extracted fonts.
$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.pdf";

// Initialize the response data variable.
$responseData = "";

try {
    // Load the PDF document.
    $document = new Document($inputFile);

    // Get all the fonts used in the PDF document.
    $fonts = java_values($document->getFontUtilities()->getAllFonts());

    // Iterate over each font and save it as a TrueType font file.
    foreach ($fonts as $font) {
        // Set the output file path for the font file.
        $outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . $font->getFontName() . ".ttf";

        // Create a FileOutputStream object to write the font file.
        $fontStream = new java("java.io.FileOutputStream", $outputFile);

        // Save the font as a TrueType font file.
        $font->save($fontStream);

        // Close the font stream.
        $fontStream->close();

        // Append the font name to the response data.
        $responseData = $responseData . $font->getFontName() . ", ";
    }

    // Close the PDF document.
    $document->close();
} catch (Exception $ex) {
    // If an exception occurs, encode the exception as JSON and assign it to the response data.
    $responseData = $ex;
}

// Set the response header to indicate that the response will be in JSON format.
header('Content-Type: application/json; charset=utf-8');
// Output the response data as a JSON object.
echo '{"message":"' . $responseData . '"}' . PHP_EOL;