<?php
require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

use com\aspose\pdf\Document;
use com\aspose\pdf\AnnotationType;
use com\aspose\pdf\TextAbsorber;
use com\aspose\pdf\ParagraphAbsorber;
use com\aspose\pdf\License;

/**
 * PDFTextExtractor class
 *
 * This class provides functionalities for extracting text from a PDF document using the Aspose.PDF library.
 */
class PDFTextExtractor
{
    /**
     * Extract text from a PDF document.
     *
     * This function reads a PDF document, extracts the text content from it, and saves it to a text file.     
     */
    public function extractText()
    {
        // Set the license file for Aspose.PDF library.
        $license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";
        $licenceObject = new License();
        $licenceObject->setLicense($license);

        $dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
        $inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.pdf";
        $outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-parse-text.txt';

        $responseData = "";
        try {
            // Create a new Document object from the input PDF file.
            $document = new Document($inputFile);

            // Create a new TextAbsorber object to extract text from the document.
            $textAbsorber = new TextAbsorber();

            // Extract text from the document.
            $textAbsorber->visit($document);

            // Get the extracted text content.
            $content = $textAbsorber->getText();

            // Save the extracted text to the output file.
            file_put_contents($outputFile, $content);

            $document->close();
            // Generate the response message.
            $responseData = "Text has been extracted successfully. Filesize: " . filesize($outputFile);
        } catch (Exception $ex) {
            // Handle any exceptions that occur during the text extraction process.
            $responseData = json_encode($ex);
        }


        // Return the response message as a JSON string.
        return '{"message":"' . $responseData . '"}' . PHP_EOL;
    }

    public function extractParagraph()
    {
        // Set the license file for Aspose.PDF library.
        $license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";
        $licenceObject = new License();
        $licenceObject->setLicense($license);

        $dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
        $inputFile = $dataDir . DIRECTORY_SEPARATOR . "sample.pdf";
        $outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-parse-text.txt';
        try {
            // Open an existing PDF file
            $document = new Document($inputFile);
            // Instantiate ParagraphAbsorber
            $absorber = new ParagraphAbsorber();
            $absorber->visit($document);

            $responseData = "";
            foreach ($absorber->getPageMarkups() as $markup) {
                $i = 1;

                foreach ($markup->getSections() as $section) {
                    $j = 1;

                    foreach ($section->getParagraphs() as $paragraph) {
                        $paragraphText = "\r\n";

                        foreach ($paragraph->getLines() as $line) {
                            foreach ($line as $fragment) {
                                $paragraphText = $paragraphText . $fragment->getText();
                            }
                            $paragraphText = $paragraphText . "\r\n";
                        }
                        $paragraphText = $paragraphText . "\r\n";

                        $responseData = $responseData . "Paragraph " . $j++ . " of section " . $i++ . " on page" . ":" . $markup->getNumber();
                        $responseData = $responseData . $paragraphText;
                    }
                    $j++;
                }
                $i++;
            }
            //Save the extracted text to the output file.
            file_put_contents($outputFile, $responseData);
            $document->close();
        } catch (Exception $ex) {
            // Handle any exceptions that occur during the text extraction process.
            $responseData = json_encode($ex);
        }
        return $responseData;
    }

    public function extractHighlightedText()
    {

        // Set the license file for Aspose.PDF library.
        $license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";
        $licenceObject = new License();
        $licenceObject->setLicense($license);

        $dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
        $inputFile = $dataDir . DIRECTORY_SEPARATOR . "ExtractHighlightedText";
        $outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'result-parse-text.txt';
        // Open an existing PDF file
        $document = new Document($inputFile);
        $annotationType = new AnnotationType();
        // Loop through all the annotations
        foreach ($document->getPages()->get_Item(1)->getAnnotations() as $annotation) {
            // Filter TextMarkupAnnotation
            if ($annotation->getAnnotationType() == $annotationType->Highlight) {

                // Retrieve highlighted text fragments
                $collection = $annotation->getMarkedTextFragments();
                foreach ($collection as $tf) {
                    $responseData = $tf->getText();
                }
            }
        }
        //Save the extracted text to the output file.
        file_put_contents($outputFile, $responseData);
        $document->close();
        return $responseData;
    }
}

// Instantiate the PDFTextExtractor class and call the extractText method.
$extractor = new PDFTextExtractor();
header('Content-Type: application/json; charset=utf-8');
echo $extractor->extractText();
//echo $extractor->extractParagraph();
//echo $extractor->extractHighlightedText();