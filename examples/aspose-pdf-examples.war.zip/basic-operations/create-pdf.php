<?php

require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

use com\aspose\pdf\Document;
use com\aspose\pdf\TextFragment;
use com\aspose\pdf\License;

$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";
$licenceObject = new License();
$licenceObject->setLicense($license);

$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'hello-world.pdf';

header('Content-Type: application/json; charset=utf-8');

try {
    $document = new Document();    
    $page = $document->getPages()->add();
    $textFragment = new TextFragment("Hello World!");    
    $page->getParagraphs()->add($textFragment);
    $document->save($outputFile);
    $responseData = "Document has been created successfully. Filesize: " . filesize($outputFile);
} catch (Exception $ex) {
    $responseData = $ex->getMessage();
}

echo '{"message":"' . $responseData . '"}' . PHP_EOL;
