<?php

require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

use com\aspose\pdf\Document;
use com\aspose\pdf\License;

$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";
$licenceObject = new License();
$licenceObject->setLicense($license);

$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . 'sample.pdf';
$outputFile = $dataDir . DIRECTORY_SEPARATOR . "results" . DIRECTORY_SEPARATOR . 'save-pdf.pdf';

header('Content-Type: application/json; charset=utf-8');

try {
    $document = new Document($inputFile);        
    $document->save($outputFile);
    $responseData = "Document has been created successfully. Filesize: " . filesize($outputFile);
} catch (Exception $ex) {
    $responseData = $ex;
}

echo '{"message":"' . $responseData . '"}' . PHP_EOL;
