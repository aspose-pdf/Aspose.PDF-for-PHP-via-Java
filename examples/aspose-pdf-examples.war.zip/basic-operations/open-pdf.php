<?php

require_once ("../java/Java.inc");
require_once ("../lib/aspose.pdf.php");

use com\aspose\pdf\Document;
use com\aspose\pdf\License;

$license = "C:\Keys\Aspose.PDF.PHPviaJava.lic";
$licenceObject = new License();
$licenceObject->setLicense($license);

$dataDir = getcwd() . DIRECTORY_SEPARATOR . "samples";
$inputFile = $dataDir . DIRECTORY_SEPARATOR . 'sample-enc.pdf';

header('Content-Type: application/json; charset=utf-8');

try {
    $document = new Document($inputFile,"mypassword");
        
    $responseData = "Document has been opened successfully. Filesize: " . filesize($inputFile);

} catch (Exception $ex) {
    $responseData = $ex->getMessage();
}

echo '{"message":"' . $responseData . '"}' . PHP_EOL;
