<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></a>Aspose.PDF for PHP via Java</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@1.0.0/css/bulma.min.css">
    <style>
        .fix-size {
            width: 100%;
        }
    </style>
    <script src="/AsposePdfExamples/script.js"></script>
</head>

<body>
    <section class="section">
        <div class="container">
            <h1 class="title">
                 <a class="is-link" href="/AsposePdfExamples/">Aspose.PDF for PHP via Java</a>
            </h1>
            <p class="subtitle">
                Basic Operations
            </p>
        </div>
        <div class="container">
            <div class="table-container">
                <table class="table fix-size">
                    <thead>
                        <tr>
                            <th style="width: 30%;">Operation</th>
                            <th style="width: 70%;">Result</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <button class="button fix-size is-responsive" 
                                    data-url="create-pdf">
                                    Create PDF
                                </button>
                            </td>
                            <td>
                                <output id="create-pdf">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <button class="button fix-size is-responsive" 
                                    data-url="open-pdf">
                                    Open PDF
                                </button>
                            </td>
                            <td>
                                <output id="open-pdf">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <button class="button fix-size is-responsive" 
                                    data-url="save-pdf">
                                    Save PDF
                                </button>
                            </td>
                            <td>
                                <output id="save-pdf">
                                    <pre>&nbsp;</pre>
                                </output>
                            </td>
                        </tr>

                    </tbody>
                </table>
            </div>
        </div>
    </section>
</body>

</html>