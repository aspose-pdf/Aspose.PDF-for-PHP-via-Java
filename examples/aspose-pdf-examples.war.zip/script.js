async function runOperation(e) {
  e.target.classList.remove("is-success");
  e.target.classList.add("is-loading");
  const requestUrl = `${window.location.href}${e.target.dataset.url}.php`;
  const element = document.getElementById(e.target.dataset.url);
  try {
    const response = await fetch(requestUrl);
    if (response.ok) {
      const res = await response.json();
      element.innerHTML = res.message;
      e.target.classList.remove("is-loading");
      e.target.classList.remove("is-danger");
      e.target.classList.add("is-success");
    } else {
      e.target.classList.remove("is-loading");
      e.target.classList.add("is-danger");
      element.innerHTML = "";
    }
  } catch (error) {
    e.target.classList.remove("is-loading");
    e.target.classList.add("is-danger");
    element.innerHTML = error;
  }
}

window.onload = (event) => {
  const buttons = document.querySelectorAll("button");
  buttons.forEach((element) => {
    element.addEventListener("click", runOperation);
  });
};
